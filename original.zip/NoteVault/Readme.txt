====================================================================
+                  BM Note Vault                                   +
====================================================================


Information / Support:
====================================================================
Product      : BM Note Vault
Version      : Version 1.1 (Build 5)
Author       : Ben Jones aka DreamVB
Release Date : January, 16, 2010
Web Site     : http://www.bm-it-software.co.uk/
Type         : FREEWARE

Program Description:

====================================================================
BM Note Vault is an easy to use freeware notes organizer that 
allows you to manage your personal and business related information, 
Ideas into manageable groups BM Note also uses a user 
friendly explorer-like interface. that is similar to windows.

Other additional features include a database backup and restore.
Opening existing databases or creating a new database. 
BM Note also uses a secure database to make sure your 
information is secure and kept safe.

Program Features:

====================================================================
 + Easy to use GUI (Graphical User Interface)
 + Add, Rename, Delete groups
 + Add, Edit, Delete, Move notes
 + Set note Priority
 + Give notes custom colours and icons
 + Backup and Restore
 + Creating databases and opening existing ones
 + Option to password your notes database
 + Rich text support
 + Check for updates

Installation:

====================================================================
To install this program simply double click the setup.exe file. 
This will then display the install dialog screen. From were you 
will need follow the on screen instructions.

System Requirements:

====================================================================
Hardware   : IBM PC 133 MHz or better. 
OS         : Win 98/ME/NT4/2K/XP/2K3, Vista, Windows7
Disk space : 5 MB of available hard disk space.
Memory     : 16 MB of RAM recommend 32 MB if using Windows XP
Other      : Microsoft Data Access Components
====================================================================

The link below provides a download for the above Database 
components if there not installed on the system.

http://www.microsoft.com/downloads/details.aspx?FamilyID=6c050fe3-c795-4b7d-b037-185d0506396c&displaylang=en
