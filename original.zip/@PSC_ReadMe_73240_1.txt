Title: BM Note Vault
Description: BM Note Vault is an easy to use freeware notes organizer that 
allows you to manage your personal and business related information, 
Ideas into manageable groups.
Hope you like this code, as this will be my last submission to the VB selection as I now moved over to C#, it been fun over the years thanks for all the good commects and votes on my submissions and I wish you all the best. Maybe we meet in the C# selection.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=73240&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
